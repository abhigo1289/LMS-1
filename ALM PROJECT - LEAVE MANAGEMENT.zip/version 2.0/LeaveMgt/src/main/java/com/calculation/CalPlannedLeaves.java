package com.calculation;

public class CalPlannedLeaves
{
	public double calPlannedLeaves(String date)
	{
		double l=0.00;
		return l;
	}

}
