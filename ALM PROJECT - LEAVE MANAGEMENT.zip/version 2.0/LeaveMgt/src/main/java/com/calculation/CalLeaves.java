package com.calculation;

public class CalLeaves 
{
	public int calLeaves(String start,String end)
	{
		int d=0;
		return d;
	}

}
