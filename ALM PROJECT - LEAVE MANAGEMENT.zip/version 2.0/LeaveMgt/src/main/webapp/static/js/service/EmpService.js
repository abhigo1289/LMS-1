'use strict';

App.service('EmpService', ['$http', function(http){
	
	this.getEmpdetails = function(id){
		return http.get('emp/'+id);						
	};
	
}]);