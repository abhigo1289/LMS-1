'use strict';

App.controller('approveleaveempCtrl', ['$scope', '$state', 'EmpService', function(scope, state, empService){
//	Cancel button
	$(".btn-warning").click(function(){
        $(".collapse").collapse('hide');
    });
	
	
	var promise = empService.getLeaves();
	
	promise.then(
			function(response){
				scope.mgrLeaves = response.data;
				console.log("Retrieved Employee Leaves to Manager");
			},
			function(error){
				alert(error.statusText);
			}
		);
	
	scope.approveLeave = function(leaveNum, empId){
		var yes = confirm("Approve Leave for Employee with id "+empId);
	};
	
	scope.disapproveLeave = function(leaveNum, empId){
		var yes = confirm("Disapprove Leave for Employee with id "+empId);
	};
	
}]);