'use strict';

App.service('EmpService', ['$http', function(http){

//	GET - gets Employee Details
	this.getEmpdetails = function(id){
		return http.get('restemp/'+id);						
	};
	
//	POST - Add new Employee details
	this.addNewEmpdetails = function(empdetails){
		return http.post('restaddnewemp/', empdetails);
	};

	
//	GET - gets Employee Approved Leave
	this.getEmpApprovedLeaves = function(id){
		return http.get('restempleave/'+id)
	}
	
//	GET - gets Employee Leave for manager to Approve
	this.getLeaves = function(id){
		return http.get('restmgrleave/');						
	};
	
//	POST - Delete employee Leave
	this.deleteEmpLeave = function(id, startDate){
		var empLeave = {"empId":id,"startDate":startDate};
		
//		return http({
//		    method: 'POST',
//		    url: 'restempleavedelete/',
//		    headers: {'Content-Type': 'application/json'},
//		    data: {"empId":id,"startDate":startDate}
//		});
		
		return http.post('restempleavedelete/',empLeave );

	};
	

	
}]);